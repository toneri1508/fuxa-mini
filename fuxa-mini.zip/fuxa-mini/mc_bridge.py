"""
mc_bridge.py  (ban 2 - dung GetDevice2/SetDevice2)
==================================================
Cau noi giua fuxa-mini (MC Protocol 3E binary) va GX Simulator qua MX Component.

    fuxa-mini --TCP:1025 (MC 3E)--> [cache] --COM--> MX Component --> GX Simulator

VI SAO BAN 2:
    pywin32 khong marshal duoc tham so mang (short* lpsData) cua
    ReadDeviceBlock2/WriteDeviceBlock2 -- no chi tra ve PHAN TU DAU TIEN.
    Nen ban nay dung GetDevice2/SetDevice2 cho tung device, va toi uu
    device kieu bit bang chi dinh digit K4 (K4M48 = 16 bit M48..M63).

    De khong phai goi COM hang tram lan, bridge chi quet nhung dia chi
    ma fuxa-mini THUC SU hoi toi (hoc dan tu cac request di vao).

Yeu cau:
    - MX Component + Logical Station da khai (mac dinh: 1)
    - Python 32-bit + pywin32

Chay:
    1. GX Works -> Start Simulation -> doi CPU vao RUN
    2. "%PY32%" mc_bridge.py
    3. fuxa-mini: IP 127.0.0.1, port 1025
"""

import socket
import struct
import threading
import queue
import time
import sys

import pythoncom
import win32com.client

# ----------------------------------------------------------------------------
# CAU HINH
# ----------------------------------------------------------------------------

LOGICAL_STATION = 1
LISTEN_HOST = "0.0.0.0"
LISTEN_PORT = 1025
POLL_INTERVAL = 0.1      # chu ky quet, giay
MAX_POLL_ITEMS = 200     # tran an toan: so lan goi COM moi vong quet
USE_K4 = True            # doc device bit theo cum 16 bit bang K4
VERBOSE = True

# He co so cua SO HIEU DEVICE khi viet thanh chuoi cho MX Component.
# MX Component dung ky phap cua GX Works: X/Y/B/W he 16, con lai he 10.
RADIX = {"X": 16, "Y": 16, "B": 16, "W": 16}

# Ma device cua MC Protocol 3E binary -> ky tu device
DEVCODE = {
    0x90: "M", 0x9C: "X", 0x9D: "Y", 0xA0: "B", 0x92: "L",
    0xA8: "D", 0xAF: "R", 0xB4: "W",
}
BITDEV = {"M", "X", "Y", "B", "L"}

EC_OK = 0x0000
EC_BAD_DEVICE = 0xC059
EC_BAD_ADDRESS = 0xC051

# ----------------------------------------------------------------------------
# TRANG THAI DUNG CHUNG
# ----------------------------------------------------------------------------

# cache: (device, so_hieu) -> gia tri 16 bit
#   device word (D/R/W): so_hieu la dia chi word
#   device bit (M/Y/..): so_hieu la dia chi bit DAU CUM, boi so cua 16;
#                        gia tri la 16 bit dong goi
cache = {}
wanted = set()            # cac khoa can quet
state_lock = threading.Lock()

write_q = queue.Queue()   # ("D100", 1234) -- luon la SetDevice2
poll_now = threading.Event()
plc_online = threading.Event()


def log(*a):
    if VERBOSE:
        print(*a, flush=True)


def devstr(name, number):
    """(Y, 26) -> 'Y1A' ; (D, 100) -> 'D100'"""
    if RADIX.get(name, 10) == 16:
        return f"{name}{number:X}"
    return f"{name}{number}"


# ----------------------------------------------------------------------------
# THREAD GIAO TIEP PLC -- TAT CA LENH COM CHI CHAY O DAY
# ----------------------------------------------------------------------------

def plc_worker():
    pythoncom.CoInitialize()
    plc = win32com.client.Dispatch("ActUtlType.ActUtlType")
    plc.ActLogicalStationNumber = LOGICAL_STATION

    rc = plc.Open()
    if rc != 0:
        print(f"[PLC] Open() that bai, ma loi 0x{rc & 0xFFFFFFFF:08X}")
        print("      Kiem tra simulator da RUN chua, Logical Station co dung khong.")
        sys.exit(1)

    print(f"[PLC] Da ket noi qua Logical Station {LOGICAL_STATION}")
    plc_online.set()

    k4_ok = USE_K4          # tu tat neu PLC khong nhan cu phap K4
    warned = False

    while True:
        t0 = time.time()

        # --- 1. Day lenh ghi xuong truoc ---
        while not write_q.empty():
            name, value = write_q.get()
            try:
                plc.SetDevice2(name, value)
                log(f"[PLC] W {name} = {value}")
            except Exception as e:
                print(f"[PLC] Loi ghi {name}: {e}")

        # --- 2. Quet cac dia chi dang duoc hoi ---
        with state_lock:
            keys = sorted(wanted)

        if len(keys) > MAX_POLL_ITEMS:
            if not warned:
                print(f"[PLC] CANH BAO: {len(keys)} dia chi can quet, vuot nguong "
                      f"{MAX_POLL_ITEMS}. Vong quet se cham.")
                print("      Gom cac tag ve gan nhau (vd D0..D30) de giam so luong.")
                warned = True

        for dev, num in keys:
            try:
                if dev in BITDEV and k4_ok:
                    rc, v = plc.GetDevice2("K4" + devstr(dev, num))
                    if rc != 0:
                        k4_ok = False
                        print("[PLC] PLC khong nhan cu phap K4, chuyen sang doc tung bit.")
                        continue
                elif dev in BITDEV:
                    v = 0
                    for b in range(16):
                        r2, bit = plc.GetDevice2(devstr(dev, num + b))
                        if r2 == 0 and bit:
                            v |= (1 << b)
                    rc = 0
                else:
                    rc, v = plc.GetDevice2(devstr(dev, num))

                if rc == 0:
                    with state_lock:
                        cache[(dev, num)] = v & 0xFFFF
            except Exception as e:
                if dev in BITDEV and k4_ok:
                    k4_ok = False
                    print(f"[PLC] K4 loi ({e}), chuyen sang doc tung bit.")
                else:
                    print(f"[PLC] Loi doc {devstr(dev, num)}: {e}")

        dt = time.time() - t0
        poll_now.wait(timeout=max(0.0, POLL_INTERVAL - dt))
        poll_now.clear()


def register(keys):
    """Ghi nhan dia chi can quet; danh thuc thread quet neu co dia chi moi."""
    with state_lock:
        new = [k for k in keys if k not in wanted]
        wanted.update(keys)
    if new:
        log(f"[MC ] dia chi moi: {', '.join(devstr(d, n) for d, n in new)}")
        poll_now.set()


# ----------------------------------------------------------------------------
# KHUNG MC PROTOCOL 3E BINARY
# ----------------------------------------------------------------------------

def build_response(data=b"", end_code=EC_OK):
    body = struct.pack("<H", end_code) + data
    return b"\xd0\x00\x00\xff\xff\x03\x00" + struct.pack("<H", len(body)) + body


def handle_request(req):
    if len(req) < 21:
        return build_response(end_code=EC_BAD_DEVICE)

    cmd, sub = struct.unpack("<HH", req[11:15])
    head = int.from_bytes(req[15:18], "little")
    code = req[18]
    npts = struct.unpack("<H", req[19:21])[0]

    name = DEVCODE.get(code)
    if name is None:
        log(f"[MC ] device code 0x{code:02X} khong ho tro")
        return build_response(end_code=EC_BAD_DEVICE)

    is_bit = name in BITDEV
    log(f"[MC ] cmd={cmd:04X} sub={sub:04X} {devstr(name, head)} x{npts}")

    # ---------------- 0401: Batch Read ----------------
    if cmd == 0x0401:
        if sub == 0x0000:                                  # don vi WORD
            if is_bit:
                if head % 16 != 0:
                    return build_response(end_code=EC_BAD_ADDRESS)
                keys = [(name, head + 16 * i) for i in range(npts)]
            else:
                keys = [(name, head + i) for i in range(npts)]
            register(keys)
            with state_lock:
                data = b"".join(struct.pack("<H", cache.get(k, 0)) for k in keys)
            return build_response(data)

        else:                                              # don vi BIT
            first = (head // 16) * 16
            last = ((head + npts - 1) // 16) * 16
            keys = [(name, w) for w in range(first, last + 1, 16)]
            register(keys)
            with state_lock:
                words = {k: cache.get(k, 0) for k in keys}
            bits = []
            for i in range(head, head + npts):
                w = words[(name, (i // 16) * 16)]
                bits.append((w >> (i % 16)) & 1)
            buf = bytearray()
            for i in range(0, npts, 2):
                lo = bits[i + 1] if i + 1 < npts else 0
                buf.append((bits[i] << 4) | lo)
            return build_response(bytes(buf))

    # ---------------- 1401: Batch Write ----------------
    if cmd == 0x1401:
        payload = req[21:]

        if sub == 0x0000:                                  # don vi WORD
            if len(payload) < npts * 2:
                return build_response(end_code=EC_BAD_ADDRESS)
            vals = list(struct.unpack(f"<{npts}h", payload[:npts * 2]))
            if is_bit and head % 16 != 0:
                return build_response(end_code=EC_BAD_ADDRESS)
            step = 16 if is_bit else 1
            for i, v in enumerate(vals):
                num = head + i * step
                target = ("K4" + devstr(name, num)) if is_bit else devstr(name, num)
                write_q.put((target, v))
                with state_lock:
                    cache[(name, num)] = v & 0xFFFF
            return build_response()

        else:                                              # don vi BIT
            bits = []
            for b in payload:
                bits.append((b >> 4) & 1)
                bits.append(b & 1)
            bits = bits[:npts]
            for i, v in enumerate(bits):
                write_q.put((devstr(name, head + i), v))
            with state_lock:
                for i, v in enumerate(bits):
                    num = head + i
                    key = (name, (num // 16) * 16)
                    if key in cache:
                        if v:
                            cache[key] |= (1 << (num % 16))
                        else:
                            cache[key] &= ~(1 << (num % 16)) & 0xFFFF
            return build_response()

    log(f"[MC ] lenh {cmd:04X} chua duoc cai dat")
    return build_response(end_code=EC_BAD_DEVICE)


# ----------------------------------------------------------------------------
# TCP SERVER
# ----------------------------------------------------------------------------

def recv_frame(conn):
    head = b""
    while len(head) < 9:
        chunk = conn.recv(9 - len(head))
        if not chunk:
            return None
        head += chunk
    remain = struct.unpack("<H", head[7:9])[0]
    body = b""
    while len(body) < remain:
        chunk = conn.recv(remain - len(body))
        if not chunk:
            return None
        body += chunk
    return head + body


def client_thread(conn, addr):
    print(f"[NET] {addr} da ket noi")
    try:
        while True:
            req = recv_frame(conn)
            if req is None:
                break
            conn.sendall(handle_request(req))
    except Exception as e:
        print(f"[NET] {addr} loi: {e}")
    finally:
        conn.close()
        print(f"[NET] {addr} ngat ket noi")


def main():
    threading.Thread(target=plc_worker, daemon=True).start()
    if not plc_online.wait(timeout=15):
        print("[PLC] Khong ket noi duoc trong 15 giay, thoat.")
        return

    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((LISTEN_HOST, LISTEN_PORT))
    srv.listen(5)
    print(f"[NET] MC Protocol server dang lang nghe {LISTEN_HOST}:{LISTEN_PORT}")

    try:
        while True:
            conn, addr = srv.accept()
            conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            threading.Thread(target=client_thread, args=(conn, addr), daemon=True).start()
    except KeyboardInterrupt:
        print("\n[NET] Dung server.")
    finally:
        srv.close()


if __name__ == "__main__":
    main()
